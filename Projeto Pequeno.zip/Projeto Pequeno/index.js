var express = require("express");
const req = require("express/lib/request");
var app = express();
const usuarioRoute = require("./routes/usuarioRoute");
const acervoRoute = require("./routes/acervoRoute");
const livroRoute = require("./routes/livroRoute");

app.set("view engine", "ejs");

app.use(express.urlencoded({ extended: false }));

app.use(express.static("./public"));

require("./config/database.js");

app.use("/usuario", usuarioRoute);
app.use("/acervo", acervoRoute);
app.use("/livro", livroRoute);

app.listen("3000", () => {
  console.log("Conexão iniciada na porta 3000");
});
