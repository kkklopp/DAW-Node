const { Model, DataTypes } = require("sequelize");

class Acervo extends Model {
  static init(conexao) {
    super.init(
      {
        foto: DataTypes.STRING,
        nome: DataTypes.STRING,
        exemplares: DataTypes.STRING,
        computadores: DataTypes.STRING,
        endereco: DataTypes.STRING,
        funcionamento: DataTypes.STRING,
      },
      { sequelize: conexao, freezeTableName: true, tableName: "acervo" }
    );
  }
}

module.exports = Acervo;
