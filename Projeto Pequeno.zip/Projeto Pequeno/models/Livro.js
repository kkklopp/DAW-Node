const { Model, DataTypes } = require("sequelize");

class Livro extends Model {
  static init(conexao) {
    super.init(
      {
        foto: DataTypes.STRING,
        titulo: DataTypes.STRING,
        data: DataTypes.STRING,
        genero: DataTypes.STRING,
        paginas: DataTypes.STRING,
        acervo: DataTypes.STRING,
      },
      { sequelize: conexao, freezeTableName: true, tableName: "livro" }
    );
  }
}

module.exports = Livro;
