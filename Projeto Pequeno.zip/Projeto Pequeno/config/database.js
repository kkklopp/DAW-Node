const sequelize = require("sequelize");
const dbconfig = require("./dbconfig.js");
const Usuario = require("../models/Usuario.js");
const Acervo = require("../models/Acervo.js");
const Livro = require("../models/Livro.js");
const conexao = new sequelize(dbconfig);

Usuario.init(conexao);
Acervo.init(conexao);
Livro.init(conexao);

module.exports = conexao;
