module.exports = {
  username: "postgres",
  password: "postgres",
  database: "ProjetoPequeno",
  host: "127.0.0.1",
  port: "5432",
  dialect: "postgres",
  define: {
    timestamps: false,
  },
};
