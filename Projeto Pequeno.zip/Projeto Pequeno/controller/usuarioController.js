const { Op } = require("sequelize");
const Usuario = require("../models/Usuario.js");

async function abreadd(req, res) {
  res.render("usuario/add.ejs", {});
}
async function add(req, res) {
  const { nome, email, senha } = req.body;
  console.log(req.file);
  const foto = req.file.filename;

  await Usuario.create({ nome, email, senha, foto }).then((users) => {
    res.redirect("/usuario");
  });
}
async function abreedt(req, res) {
  let users = await Usuario.findByPk(req.params.id);
  res.render("usuario/edt.ejs", { users: users });
}
async function edt(req, res) {
  let users = await Usuario.findByPk(req.params.id);
  users.nome = req.body.nome;
  users.email = req.body.email;
  users.senha = req.body.senha;

  console.log(req.file);

  if (req.body.foto != undefined) {
    users.foto = req.file.filename;
  }
  await users.save();
  res.redirect("/usuario");
}
async function list(req, res) {
  let users = await Usuario.findAll();
  res.render("usuario/index.ejs", { Usuario: users });
}
async function listfiltro(req, res) {
  let pesquisar = req.body.pesquisar;
  let users = await Usuario.findAll({
    where: { nome: { [Op.iLike]: pesquisar } },
  });
  res.render("usuario/index.ejs", { Usuario: users });
}
async function del(req, res) {
  let users = await Usuario.findByPk(req.params.id);
  await users.destroy();
  res.redirect("/usuario");
}

module.exports = { abreadd, add, abreedt, edt, list, listfiltro, del };
