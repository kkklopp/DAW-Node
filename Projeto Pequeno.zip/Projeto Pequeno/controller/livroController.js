const { Op } = require("sequelize");
const Livro = require("../models/Livro.js");

async function abreadd(req, res) {
  res.render("livro/add.ejs", {});
}
async function add(req, res) {
  const { titulo, data, genero, paginas, acervo } = req.body;
  console.log(req.file);
  const foto = req.file.filename;

  await Livro.create({
    foto,
    titulo,
    data,
    genero,
    paginas,
    acervo,
  }).then((livro) => {
    res.redirect("/livro");
  });
}
async function abreedt(req, res) {
  let livro = await Livro.findByPk(req.params.id);
  res.render("livro/edt.ejs", { livro: livro });
}
async function edt(req, res) {
  let livro = await Livro.findByPk(req.params.id);
  livro.titulo = req.body.titulo;
  livro.data = req.body.data;
  livro.genero = req.body.genero;
  livro.paginas = req.body.paginas;
  livro.acervo = req.body.acervo;

  console.log(req.file);

  if (req.body.foto != undefined) {
    livro.foto = req.file.filename;
  }
  await livro.save();
  res.redirect("/livro");
}
async function list(req, res) {
  let livro = await Livro.findAll();
  res.render("livro/index.ejs", { Livro: livro });
}
async function listfiltro(req, res) {
  let pesquisar = req.body.pesquisar;
  let livro = await Livro.findAll({
    where: { titulo: { [Op.iLike]: pesquisar } },
  });
  res.render("livro/index.ejs", { Livro: livro });
}
async function del(req, res) {
  let livro = await Livro.findByPk(req.params.id);
  await livro.destroy();
  res.redirect("/livro");
}

module.exports = { abreadd, add, abreedt, edt, list, listfiltro, del };
