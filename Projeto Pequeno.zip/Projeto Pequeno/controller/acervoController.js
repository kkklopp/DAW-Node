const { Op } = require("sequelize");
const Acervo = require("../models/Acervo.js");

async function abreadd(req, res) {
  res.render("acervo/add.ejs", {});
}
async function add(req, res) {
  const { nome, exemplares, computadores, endereco, funcionamento } = req.body;
  console.log(req.file);
  const foto = req.file.filename;

  await Acervo.create({
    foto,
    nome,
    exemplares,
    computadores,
    endereco,
    funcionamento,
  }).then((acervo) => {
    res.redirect("/acervo");
  });
}
async function abreedt(req, res) {
  let acervo = await Acervo.findByPk(req.params.id);
  res.render("acervo/edt.ejs", { acervo: acervo });
}
async function edt(req, res) {
  let acervo = await Acervo.findByPk(req.params.id);
  acervo.nome = req.body.nome;
  acervo.exemplares = req.body.exemplares;
  acervo.computadores = req.body.computadores;
  acervo.endereco = req.body.endereco;
  acervo.funcionamento = req.body.funcionamento;

  console.log(req.file);

  if (req.body.foto != undefined) {
    acervo.foto = req.file.filename;
  }
  await acervo.save();
  res.redirect("/acervo");
}
async function list(req, res) {
  let acervo = await Acervo.findAll();
  res.render("acervo/index.ejs", { Acervo: acervo });
}
async function listfiltro(req, res) {
  let pesquisar = req.body.pesquisar;
  let acervo = await Acervo.findAll({
    where: { nome: { [Op.iLike]: pesquisar } },
  });
  res.render("acervo/index.ejs", { Acervo: acervo });
}
async function del(req, res) {
  let acervo = await Acervo.findByPk(req.params.id);
  await acervo.destroy();
  res.redirect("/acervo");
}

module.exports = { abreadd, add, abreedt, edt, list, listfiltro, del };
