var express = require("express");
var router = express.Router();
const usuarioController = require("../controller/usuarioController");
const multer = require("../config/multer");

router.get("/", usuarioController.list);
router.post("/", usuarioController.listfiltro);
router.get("/add", usuarioController.abreadd);
router.post("/add", multer.single("foto"), usuarioController.add);
router.get("/edt/:id", usuarioController.abreedt);
router.post("/edt/:id", multer.single("foto"), usuarioController.edt);
router.get("/del/:id", usuarioController.del);

module.exports = router;
