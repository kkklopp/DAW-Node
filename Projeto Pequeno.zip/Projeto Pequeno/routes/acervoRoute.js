var express = require("express");
var router = express.Router();
const acervoController = require("../controller/acervoController");
const multer = require("../config/multer");

router.get("/", acervoController.list);
router.post("/", acervoController.listfiltro);
router.get("/add", acervoController.abreadd);
router.post("/add", multer.single("foto"), acervoController.add);
router.get("/edt/:id", acervoController.abreedt);
router.post("/edt/:id", multer.single("foto"), acervoController.edt);
router.get("/del/:id", acervoController.del);

module.exports = router;
