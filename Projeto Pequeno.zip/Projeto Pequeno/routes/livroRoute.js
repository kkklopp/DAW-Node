var express = require("express");
var router = express.Router();
const livroController = require("../controller/livroController");
const multer = require("../config/multer");

router.get("/", livroController.list);
router.post("/", livroController.listfiltro);
router.get("/add", livroController.abreadd);
router.post("/add", multer.single("foto"), livroController.add);
router.get("/edt/:id", livroController.abreedt);
router.post("/edt/:id", multer.single("foto"), livroController.edt);
router.get("/del/:id", livroController.del);

module.exports = router;
